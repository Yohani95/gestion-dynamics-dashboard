"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, Calendar, Building2, FileText, Download,
  ChevronLeft, ChevronRight, Filter, List, ArrowUpRight,
  Printer, FileJson, FileSpreadsheet, AlertCircle, CheckCircle2,
  Clock, Info, MoreHorizontal, RefreshCw, FileUp, RotateCcw,
} from "lucide-react";
import { rowsToCsv, downloadCsv, downloadXlsxTable, triggerPrint } from "@/lib/exportUtils";
import { useInstance, fetchWithInstance } from "./InstanceContext";
import { useAdminSession } from "./AdminSessionContext";

type DocItem = {
  tipo: string;
  numero: number;
  idDocumento: string;
  codEmpresa?: string;
  fechaEmision: string;
  estadoSII: number | null;
  estadoEnvio: number | null;
  lineasGestion: number;
  lineasDynamicsOk: number;
};

type Empresa = { codEmpresa: string; descripcion: string };

type Props = {
  onVerDetalle: (numero: number) => void;
};

const getSiiLabel = (e: number | null) =>
  e === 2 ? "Timbrado" : e === 1 ? "Sin timbrar" : "—";

const getDynLabel = (e: number | null) => {
  if (e == null || e === 0) return "Sin enviar";
  const t: Record<number, string> = {
    1: "Enviada",
    2: "Loc. OK",
    3: "Registrado",
    4: "Medio de pago listo",
  };
  return t[e] ?? e;
};

function getLineasSyncState(doc: DocItem) {
  const total = Math.max(0, doc.lineasGestion ?? 0);
  const syncedRaw = Math.max(0, doc.lineasDynamicsOk ?? 0);
  const synced = Math.min(total, syncedRaw);
  const hasLineas = total > 0;
  const complete = hasLineas && synced >= total;
  return { total, synced, hasLineas, complete };
}

const PAGE_SIZES = [25, 50, 100, 200];
const FOLDER_MASIVO_MAX_POR_LOTE = 40;
const REPROCESO_MASIVO_MAX_POR_LOTE = 40;
const STORAGE_KEY_BASE = "gestion-dash-lista";

function fechaEmisionParaApi(fechaEmision: string): string {
  const t = fechaEmision.trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(t)) return t.slice(0, 10);
  const d = new Date(t);
  if (!Number.isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  return t.slice(0, 10);
}

function getStorageKey(instance: string) {
  return `${STORAGE_KEY_BASE}-${instance}`;
}

function loadPersisted(instance: string) {
  if (typeof window === "undefined") return null;
  try {
    const raw = sessionStorage.getItem(getStorageKey(instance));
    if (!raw) return null;
    return JSON.parse(raw) as {
      fecha: string;
      empresa: string;
      tipo: string;
      numero: string;
      page: number;
      pageSize: number;
      soloDuplicados?: boolean;
    };
  } catch {
    return null;
  }
}

function savePersisted(
  instance: string,
  p: { fecha: string; empresa: string; tipo: string; numero: string; page: number; pageSize: number; soloDuplicados: boolean },
) {
  try {
    sessionStorage.setItem(getStorageKey(instance), JSON.stringify(p));
  } catch { }
}

export default function DocumentosPorFecha({ onVerDetalle }: Props) {
  const { instance } = useInstance();
  const { isAdmin, loading: sessionLoading } = useAdminSession();
  const [fecha, setFecha] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [tipo, setTipo] = useState("");
  const [numeroFilter, setNumeroFilter] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [loading, setLoading] = useState(false);
  const [loadingEmpresas, setLoadingEmpresas] = useState(true);
  const [list, setList] = useState<DocItem[] | null>(null);
  const [total, setTotal] = useState(0);
  const [totalPaginas, setTotalPaginas] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [filtroTabla, setFiltroTabla] = useState("");
  const [filtroColTipo, setFiltroColTipo] = useState("");
  const [filtroColSII, setFiltroColSII] = useState("");
  const [filtroColDynamics, setFiltroColDynamics] = useState("");
  const [filtroLineas, setFiltroLineas] = useState<"" | "diff" | "complete">("");
  const [soloDuplicados, setSoloDuplicados] = useState(false);
  const [timbrandoMasivo, setTimbrandoMasivo] = useState(false);
  const [timbrarMasivoResult, setTimbrarMasivoResult] = useState<{
    ok: boolean;
    text: string;
    fallos?: { numero: string; tipo: string; detalle: string }[];
  } | null>(null);
  const [reprocesandoMasivo, setReprocesandoMasivo] = useState(false);
  const [reprocesoMasivoResult, setReprocesoMasivoResult] = useState<{
    ok: boolean;
    text: string;
    fallos?: { numero: string; tipo: string; detalle: string }[];
  } | null>(null);

  useEffect(() => {
    const p = loadPersisted(instance);
    if (p) {
      setFecha(p.fecha);
      setEmpresa(p.empresa);
      setTipo(p.tipo);
      setNumeroFilter(p.numero);
      setPage(p.page);
      setPageSize(p.pageSize);
      if (typeof p.soloDuplicados === "boolean") setSoloDuplicados(p.soloDuplicados);
      return;
    }
    setEmpresa("");
    setTipo("");
    setNumeroFilter("");
    setPage(1);
    setPageSize(50);
    setSoloDuplicados(false);
  }, [instance]);

  useEffect(() => {
    let cancelled = false;
    setLoadingEmpresas(true);
    fetchWithInstance("/api/empresas", {}, instance)
      .then((r) => r.json())
      .then((json) => {
        if (!cancelled && json.empresas) {
          const rows = json.empresas as Empresa[];
          setEmpresas(rows);
          // Si la empresa persistida no existe en la instancia actual, limpiar filtro.
          setEmpresa((prev) => (prev && !rows.some((e) => e.codEmpresa === prev) ? "" : prev));
        }
      })
      .catch(() => { })
      .finally(() => { if (!cancelled) setLoadingEmpresas(false); });
    return () => { cancelled = true; };
  }, [instance]);

  async function loadDocumentos(pageNum: number = page, overridePageSize?: number) {
    const f = fecha.trim();
    if (!f) return;
    const size = overridePageSize ?? pageSize;
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        fecha: f,
        page: String(pageNum),
        pageSize: String(size),
      });
      if (empresa) params.set("empresa", empresa);
      if (tipo) params.set("tipo", tipo);
      if (numeroFilter.trim()) params.set("numero", numeroFilter.trim());
      if (filtroTabla.trim()) params.set("search", filtroTabla.trim());
      if (filtroColTipo) params.set("tipoCol", filtroColTipo);
      if (filtroColSII !== "") params.set("sii", filtroColSII);
      if (filtroColDynamics !== "") params.set("dynamics", filtroColDynamics);
      if (soloDuplicados) params.set("duplicados", "1");
      const res = await fetchWithInstance(`/api/documentos?${params.toString()}`, {}, instance);
      const json = await res.json();
      if (!res.ok) {
        setError(json.error ?? "Error al cargar");
        setList([]);
        setTotal(0);
        setTotalPaginas(0);
        return;
      }
      setList(json.documentos ?? []);
      setTotal(json.total ?? 0);
      setTotalPaginas(json.totalPaginas ?? 1);
      setPage(pageNum);
      if (overridePageSize != null) setPageSize(overridePageSize);
      savePersisted(instance, {
        fecha: f,
        empresa,
        tipo,
        numero: numeroFilter,
        page: pageNum,
        pageSize: size,
        soloDuplicados,
      });
    } catch (err) {
      setError(String(err));
      setList([]);
      setTotal(0);
      setTotalPaginas(0);
    } finally {
      setLoading(false);
    }
  }

  async function handleBuscar(e: React.FormEvent) {
    e.preventDefault();
    setPage(1);
    await loadDocumentos(1);
  }

  function handlePageChange(nextPage: number) {
    if (nextPage < 1 || nextPage > totalPaginas || loading) return;
    loadDocumentos(nextPage);
  }

  useEffect(() => {
    if (list == null) return;
    const t = setTimeout(() => {
      loadDocumentos(1);
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtroTabla, filtroColTipo, filtroColSII, filtroColDynamics, soloDuplicados]);

  const hoy = new Date().toISOString().slice(0, 10);
  const desde = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const hasta = Math.min(page * pageSize, total);

  const listaVisibleBase = list ?? [];
  const listaVisible =
    filtroLineas === ""
      ? listaVisibleBase
      : listaVisibleBase.filter((d) => {
          const lineasState = getLineasSyncState(d);
          if (!lineasState.hasLineas) return false;
          return filtroLineas === "diff" ? !lineasState.complete : lineasState.complete;
        });
  const candidatosFolder = listaVisible.filter((d) => d.estadoSII === 1 && d.codEmpresa);
  const candidatosReproceso = listaVisible.filter(
    (d) => d.estadoSII === 2 && d.codEmpresa && d.idDocumento,
  );

  const folderMasivoDisabled =
    timbrandoMasivo ||
    reprocesandoMasivo ||
    !fecha.trim() ||
    list === null ||
    candidatosFolder.length === 0;

  const reprocesoMasivoDisabled =
    reprocesandoMasivo ||
    timbrandoMasivo ||
    !fecha.trim() ||
    list === null ||
    candidatosReproceso.length === 0;

  const folderMasivoTitle = !fecha.trim()
    ? "Indique fecha de emisión"
    : list === null
      ? "Pulse «Consultar Documentos» para cargar la lista"
      : candidatosFolder.length === 0
        ? "Ningún documento de esta página está «Sin timbrar» (SII); use el filtro de columna SII o otra página"
        : `Enviar a Folder hasta ${FOLDER_MASIVO_MAX_POR_LOTE} documentos sin timbrar de la página actual`;

  const reprocesoMasivoTitle = !fecha.trim()
    ? "Indique fecha de emisión"
    : list === null
      ? "Pulse «Consultar Documentos» para cargar la lista"
      : candidatosReproceso.length === 0
        ? "Ningún documento de esta página está «Timbrado» (SII); el reproceso a Dynamics exige timbre SII"
        : `Reprocesar en Dynamics hasta ${REPROCESO_MASIVO_MAX_POR_LOTE} documentos timbrados de la página actual`;

  async function handleTimbrarMasivoPagina() {
    const slice = candidatosFolder.slice(0, FOLDER_MASIVO_MAX_POR_LOTE);
    const items = slice.map((d) => ({
      numero: String(d.numero),
      tipo: d.tipo,
      empresa: d.codEmpresa!,
    }));
    if (items.length === 0) return;
    const omitidos = candidatosFolder.length - items.length;
    const msgOmitidos =
      omitidos > 0
        ? ` (solo los primeros ${FOLDER_MASIVO_MAX_POR_LOTE} de ${candidatosFolder.length}; repita para el resto)`
        : "";
    if (
      !window.confirm(
        `Enviar ${items.length} documento(s) de esta página (sin timbrar SII) a Folder.${msgOmitidos} ¿Continuar?`,
      )
    ) {
      return;
    }
    setTimbrandoMasivo(true);
    setTimbrarMasivoResult(null);
    setReprocesoMasivoResult(null);
    try {
      const res = await fetchWithInstance(
        "/api/documento/enviar-sii",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ documentos: items }),
        },
        instance,
      );
      const json = await res.json();
      if (json.masivo && Array.isArray(json.resultados)) {
        const fallos = (json.resultados as { ok?: boolean; numero?: string; tipo?: string; mensaje?: string; error?: string }[])
          .filter((r) => !r.ok)
          .map((r) => ({
            numero: String(r.numero ?? ""),
            tipo: String(r.tipo ?? ""),
            detalle: r.error ?? r.mensaje ?? "Error",
          }));
        setTimbrarMasivoResult({
          ok: json.fallidos === 0,
          text: `Página: ${json.total} enviados. Exitosos: ${json.exitosos}. Fallidos: ${json.fallidos}.`,
          fallos: fallos.length ? fallos : undefined,
        });
      } else {
        setTimbrarMasivoResult({
          ok: json.ok === true,
          text: json.error ?? json.mensaje ?? "Respuesta inesperada del servidor.",
        });
      }
      await loadDocumentos(page);
    } catch (e) {
      setTimbrarMasivoResult({ ok: false, text: String(e) });
    } finally {
      setTimbrandoMasivo(false);
    }
  }

  async function handleReprocesarMasivoPagina() {
    const slice = candidatosReproceso.slice(0, REPROCESO_MASIVO_MAX_POR_LOTE);
    const documentos = slice.map((d) => ({
      idDocumento: d.idDocumento,
      codEmpresa: d.codEmpresa!,
      fecha: fechaEmisionParaApi(d.fechaEmision),
      numero: String(d.numero),
      tipo: d.tipo,
    }));
    if (documentos.length === 0) return;
    const omitidos = candidatosReproceso.length - documentos.length;
    const msgOmitidos =
      omitidos > 0
        ? ` (solo los primeros ${REPROCESO_MASIVO_MAX_POR_LOTE} de ${candidatosReproceso.length}; repita para el resto)`
        : "";
    if (
      !window.confirm(
        `Reprocesar ${documentos.length} documento(s) timbrados (SII) hacia Dynamics.${msgOmitidos} ¿Continuar?`,
      )
    ) {
      return;
    }
    setReprocesandoMasivo(true);
    setReprocesoMasivoResult(null);
    setTimbrarMasivoResult(null);
    try {
      const res = await fetchWithInstance(
        "/api/documento/reprocesar",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ documentos }),
        },
        instance,
      );
      const json = await res.json();
      if (json.masivo && Array.isArray(json.resultados)) {
        const fallos = (json.resultados as { ok?: boolean; numero?: string; tipo?: string; mensaje?: string; error?: string }[])
          .filter((r) => !r.ok)
          .map((r) => ({
            numero: String(r.numero ?? ""),
            tipo: String(r.tipo ?? ""),
            detalle: r.error ?? r.mensaje ?? "Error",
          }));
        setReprocesoMasivoResult({
          ok: json.fallidos === 0,
          text: `Reproceso: ${json.total} ejecutados. Exitosos: ${json.exitosos}. Fallidos: ${json.fallidos}.`,
          fallos: fallos.length ? fallos : undefined,
        });
      } else {
        setReprocesoMasivoResult({
          ok: json.ok === true,
          text: json.error ?? json.mensaje ?? "Respuesta inesperada del servidor.",
        });
      }
      await loadDocumentos(page);
    } catch (e) {
      setReprocesoMasivoResult({ ok: false, text: String(e) });
    } finally {
      setReprocesandoMasivo(false);
    }
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 md:space-y-8 pb-10 px-4 md:px-0">
      {/* Control Panel (Glassmorphism) */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-50 border border-zinc-200/60 rounded-3xl md:rounded-[2.5rem] p-6 md:p-8 shadow-sm relative overflow-hidden group"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

        <div className="flex items-center justify-between mb-6 md:mb-8 relative z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 md:p-2.5 bg-white rounded-xl text-indigo-600 shadow-sm border border-zinc-200/50">
              <Filter className="w-4 h-4 md:w-5 md:h-5" />
            </div>
            <div>
              <h4 className="text-xs md:text-sm font-black text-zinc-900 uppercase tracking-[0.2em]">
                Auditoría de Documentos
              </h4>
              <p className="text-[9px] md:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mt-0.5">Búsqueda avanzada de transacciones</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleBuscar} className="space-y-5 md:space-y-6 relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <div className="space-y-1.5 md:space-y-2">
              <label className="text-[10px] md:text-[11px] font-bold text-zinc-400 flex items-center gap-2 uppercase tracking-wider ml-1">
                <Calendar className="w-3 h-3 md:w-3.5 md:h-3.5" />
                Fecha Emisión
              </label>
              <input
                type="date"
                value={fecha}
                onChange={(e) => setFecha(e.target.value)}
                max={hoy}
                className="w-full bg-white border border-zinc-200 rounded-xl md:rounded-2xl px-3 py-2.5 md:px-4 md:py-3 text-xs md:text-sm font-bold text-zinc-800 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none shadow-sm"
              />
            </div>

            <div className="space-y-1.5 md:space-y-2">
              <label className="text-[10px] md:text-[11px] font-bold text-zinc-400 flex items-center gap-2 uppercase tracking-wider ml-1">
                <FileText className="w-3 h-3 md:w-3.5 md:h-3.5" />
                N° Documento
              </label>
              <input
                type="text"
                value={numeroFilter}
                onChange={(e) => setNumeroFilter(e.target.value)}
                placeholder="Ej: 6512585"
                className="w-full bg-white border border-zinc-200 rounded-xl md:rounded-2xl px-3 py-2.5 md:px-4 md:py-3 text-xs md:text-sm font-bold text-zinc-800 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none shadow-sm placeholder:text-zinc-300 placeholder:font-normal"
              />
            </div>

            <div className="space-y-1.5 md:space-y-2">
              <label className="text-[10px] md:text-[11px] font-bold text-zinc-400 flex items-center gap-2 uppercase tracking-wider ml-1">
                <Building2 className="w-3 h-3 md:w-3.5 md:h-3.5" />
                Empresa Origen
              </label>
              <select
                value={empresa}
                onChange={(e) => setEmpresa(e.target.value)}
                disabled={loadingEmpresas}
                className="w-full bg-white border border-zinc-200 rounded-xl md:rounded-2xl px-3 py-2.5 md:px-4 md:py-3 text-xs md:text-sm font-bold text-zinc-800 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none appearance-none shadow-sm disabled:opacity-50"
              >
                <option value="">Todas las Entidades</option>
                {empresas.map((e) => (
                  <option key={e.codEmpresa} value={e.codEmpresa}>{e.descripcion}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5 md:space-y-2">
              <label className="text-[10px] md:text-[11px] font-bold text-zinc-400 flex items-center gap-2 uppercase tracking-wider ml-1">
                <List className="w-3 h-3 md:w-3.5 md:h-3.5" />
                Tipo Doc.
              </label>
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-xl md:rounded-2xl px-3 py-2.5 md:px-4 md:py-3 text-xs md:text-sm font-bold text-zinc-800 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none appearance-none shadow-sm"
              >
                <option value="">Todos los Tipos</option>
                <option value="BLE">Boleta (BLE)</option>
                <option value="FCV">Factura (FCV)</option>
                <option value="NCV">Nota Crédito (NCV)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 py-2 shadow-sm">
              <span className="text-[10px] md:text-[11px] font-black text-zinc-500 uppercase tracking-widest">
                Líneas
              </span>
              <select
                value={filtroLineas}
                onChange={(e) => setFiltroLineas(e.target.value as "" | "diff" | "complete")}
                className="bg-transparent border-none text-[10px] md:text-[11px] p-0 font-black text-indigo-600 focus:ring-0 appearance-none cursor-pointer"
                aria-label="Filtro de líneas"
              >
                <option value="">(TODOS)</option>
                <option value="diff">Con diferencia</option>
                <option value="complete">Completas</option>
              </select>
            </div>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-rose-200/80 bg-rose-50/80 px-3 py-2 shadow-sm select-none">
              <input
                type="checkbox"
                checked={soloDuplicados}
                onChange={(e) => setSoloDuplicados(e.target.checked)}
                className="h-3.5 w-3.5 rounded border-rose-300 text-rose-600 focus:ring-rose-500/30"
                aria-label="Solo documentos con número de folio repetido"
              />
              <span className="text-[10px] md:text-[11px] font-black text-rose-900">
                Solo folios duplicados
              </span>
            </label>
            {filtroLineas !== "" && (
              <p className="text-[10px] md:text-xs font-semibold text-zinc-500">
                Vista filtrada: {listaVisible.length}/{listaVisibleBase.length} en esta página
              </p>
            )}
            {soloDuplicados && (
              <p className="text-[10px] md:text-xs font-semibold text-rose-800/90 max-w-md leading-snug">
                Mismo <strong>Nº impreso</strong> en más de un documento (tipos/empresas distintos o varias cabeceras). Combina con empresa/tipo/SII arriba.
              </p>
            )}
          </div>

          <div className="pt-4 md:pt-6 border-t border-zinc-100 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="hidden md:flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Motor de búsqueda activo</span>
            </div>

            <div className="flex w-full md:w-auto flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:justify-end">
              {sessionLoading && (
                <span className="inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-3 text-xs font-medium text-zinc-500">
                  <RefreshCw className="h-4 w-4 animate-spin shrink-0" aria-hidden />
                  Verificando sesión…
                </span>
              )}
              {!sessionLoading && isAdmin && (
                <button
                  type="button"
                  id="folder-masivo-btn"
                  onClick={handleTimbrarMasivoPagina}
                  disabled={folderMasivoDisabled}
                  title={folderMasivoTitle}
                  className="w-full sm:w-auto shrink-0 h-12 md:h-14 px-4 md:px-5 inline-flex items-center justify-center gap-2 rounded-xl md:rounded-[1.25rem] border-2 border-amber-400/80 bg-amber-50 text-amber-950 text-xs md:text-sm font-bold hover:bg-amber-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
                >
                  {timbrandoMasivo ? (
                    <RefreshCw className="w-4 h-4 md:w-5 md:h-5 animate-spin shrink-0" aria-hidden />
                  ) : (
                    <FileUp className="w-4 h-4 md:w-5 md:h-5 shrink-0" aria-hidden />
                  )}
                  <span>Folder masivo</span>
                  <span className="tabular-nums rounded-md bg-amber-200/80 px-1.5 py-0.5 text-[10px] md:text-xs">
                    {candidatosFolder.length} sin timbrar
                  </span>
                </button>
              )}
              {!sessionLoading && isAdmin && (
                <button
                  type="button"
                  id="reproceso-masivo-btn"
                  onClick={handleReprocesarMasivoPagina}
                  disabled={reprocesoMasivoDisabled}
                  title={reprocesoMasivoTitle}
                  className="w-full sm:w-auto shrink-0 h-12 md:h-14 px-4 md:px-5 inline-flex items-center justify-center gap-2 rounded-xl md:rounded-[1.25rem] border-2 border-indigo-400/80 bg-indigo-50 text-indigo-950 text-xs md:text-sm font-bold hover:bg-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
                >
                  {reprocesandoMasivo ? (
                    <RefreshCw className="w-4 h-4 md:w-5 md:h-5 animate-spin shrink-0" aria-hidden />
                  ) : (
                    <RotateCcw className="w-4 h-4 md:w-5 md:h-5 shrink-0" aria-hidden />
                  )}
                  <span>Reprocesar masivo</span>
                  <span className="tabular-nums rounded-md bg-indigo-200/80 px-1.5 py-0.5 text-[10px] md:text-xs">
                    {candidatosReproceso.length} timbrados
                  </span>
                </button>
              )}
              {!sessionLoading && !isAdmin && (
                <p className="w-full sm:max-w-md rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-3 py-2 text-left text-[10px] md:text-xs leading-snug text-zinc-600">
                  <strong className="text-zinc-800">Folder masivo</strong> solo con sesión de administrador.
                  Use arriba a la derecha <strong className="text-zinc-800">«Iniciar sesión admin»</strong> o cierre y vuelva a entrar si ya aparece <strong className="text-zinc-800">Admin</strong>.
                  Debe estar en <strong className="text-zinc-800">Ventas (Dynamics)</strong> → pestaña <strong className="text-zinc-800">Historial por Fecha</strong> (no en Inicio).
                </p>
              )}
              <button
                type="submit"
                disabled={loading || !fecha}
                className="w-full md:w-auto px-10 h-12 md:h-14 bg-zinc-900 text-white text-xs md:text-sm font-bold rounded-xl md:rounded-[1.25rem] hover:bg-zinc-800 transition-all active:scale-95 disabled:opacity-30 inline-flex items-center justify-center gap-3 shadow-xl shadow-zinc-200/50"
              >
                {loading ? <RefreshCw className="w-4 h-4 md:w-5 md:h-5 animate-spin" /> : <Search className="w-4 h-4 md:w-5 md:h-5" />}
                Consultar Documentos
              </button>
            </div>
          </div>
        </form>
      </motion.div>

      {error && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="rounded-2xl border border-rose-100 bg-rose-50/50 p-4 flex items-center gap-3 text-rose-800"
        >
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-xs md:text-sm font-bold">{error}</p>
        </motion.div>
      )}

      {list && (
        <AnimatePresence mode="wait">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl md:rounded-[2.5rem] border border-zinc-100 bg-white shadow-xl shadow-zinc-200/30 overflow-hidden"
            id="documentos-fecha-reporte"
          >
            {/* Table Header / Toolbar */}
            <div className="px-5 py-5 md:px-8 md:py-6 border-b border-zinc-100 bg-zinc-50/50 flex flex-col sm:flex-row flex-wrap items-center justify-between gap-4 md:gap-6">
              <div className="flex items-center gap-3 md:gap-4 self-start">
                <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 shadow-inner">
                  <ArrowUpRight className="w-4 h-4 md:w-5 md:h-5" />
                </div>
                <div>
                  <h5 className="text-xs md:text-sm font-bold text-zinc-900 leading-none">Resultados de Consulta</h5>
                  <p className="text-[9px] md:text-[11px] text-zinc-400 font-medium mt-1">Consolidado: {total} documentos encontrados</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 md:gap-3 w-full sm:w-auto">
                {/* Internal Search */}
                <div className="relative group flex-1 sm:flex-initial">
                  <Search className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-zinc-300 group-focus-within:text-indigo-500 transition-colors" />
                  <input
                    type="text"
                    value={filtroTabla}
                    onChange={(e) => setFiltroTabla(e.target.value)}
                    placeholder="Filtrar en vista..."
                    className="bg-white border border-zinc-200 rounded-xl pl-9 md:pl-10 pr-4 py-2 md:py-2.5 text-[10px] md:text-xs font-bold text-zinc-800 focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500 outline-none w-full sm:w-40 md:w-48 transition-all"
                  />
                </div>

                <div className="h-6 md:h-8 w-px bg-zinc-200 mx-1 hidden sm:block" />

                <div className="flex items-center gap-1.5 md:gap-2 flex-wrap">
                  {!sessionLoading && isAdmin && (
                    <button
                      type="button"
                      onClick={handleTimbrarMasivoPagina}
                      disabled={timbrandoMasivo || reprocesandoMasivo || candidatosFolder.length === 0}
                      className="flex items-center gap-1.5 md:gap-2 px-2.5 md:px-3 py-2 md:py-2.5 rounded-lg md:rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-[10px] md:text-xs font-bold hover:bg-amber-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      title={folderMasivoTitle}
                    >
                      {timbrandoMasivo ? (
                        <RefreshCw className="w-3.5 h-3.5 md:w-4 md:h-4 animate-spin shrink-0" />
                      ) : (
                        <FileUp className="w-3.5 h-3.5 md:w-4 md:h-4 shrink-0" />
                      )}
                      <span className="hidden sm:inline">Folder</span>
                      <span className="tabular-nums">({candidatosFolder.length})</span>
                    </button>
                  )}
                  {!sessionLoading && isAdmin && (
                    <button
                      type="button"
                      onClick={handleReprocesarMasivoPagina}
                      disabled={reprocesoMasivoDisabled}
                      className="flex items-center gap-1.5 md:gap-2 px-2.5 md:px-3 py-2 md:py-2.5 rounded-lg md:rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-900 text-[10px] md:text-xs font-bold hover:bg-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      title={reprocesoMasivoTitle}
                    >
                      {reprocesandoMasivo ? (
                        <RefreshCw className="w-3.5 h-3.5 md:w-4 md:h-4 animate-spin shrink-0" />
                      ) : (
                        <RotateCcw className="w-3.5 h-3.5 md:w-4 md:h-4 shrink-0" />
                      )}
                      <span className="hidden sm:inline">Repr.</span>
                      <span className="tabular-nums">({candidatosReproceso.length})</span>
                    </button>
                  )}
                  <button
                    onClick={async () => {
                      const headers = ["Tipo", "Número", "Emisión", "SII", "Dynamics", "Líneas Total/Sync"];
                      const rows = listaVisible.map((d) => {
                        const lineasState = getLineasSyncState(d);
                        return [d.tipo, d.numero, d.fechaEmision, getSiiLabel(d.estadoSII), getDynLabel(d.estadoEnvio), `${lineasState.total}/${lineasState.synced}`];
                      });
                      await downloadXlsxTable({ filename: `reporte-docs-${fecha}`, sheetName: "Docs", headers, rows });
                    }}
                    className="p-2 md:p-2.5 text-zinc-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg md:rounded-xl border border-zinc-200 transition-all bg-white shadow-sm"
                    title="Exportar Excel"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 md:w-4.5 md:h-4.5" />
                  </button>
                  <button
                    onClick={() => triggerPrint("#documentos-fecha-reporte")}
                    className="p-2 md:p-2.5 text-zinc-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg md:rounded-xl border border-zinc-200 transition-all bg-white shadow-sm"
                    title="Imprimir"
                  >
                    <Printer className="w-3.5 h-3.5 md:w-4.5 md:h-4.5" />
                  </button>
                </div>
              </div>
            </div>

            {timbrarMasivoResult && (
              <div
                className={`mx-5 md:mx-8 mt-4 mb-2 rounded-xl border px-4 py-3 text-xs md:text-sm font-semibold ${timbrarMasivoResult.ok
                  ? "border-emerald-200 bg-emerald-50 text-emerald-900"
                  : "border-rose-200 bg-rose-50 text-rose-900"
                  }`}
              >
                <p className="font-bold text-[10px] uppercase tracking-wide text-zinc-500">Folder masivo</p>
                <p className="mt-1">{timbrarMasivoResult.text}</p>
                {timbrarMasivoResult.fallos && timbrarMasivoResult.fallos.length > 0 && (
                  <ul className="mt-2 max-h-32 overflow-y-auto space-y-1 font-mono text-[10px] md:text-xs font-normal list-disc pl-4">
                    {timbrarMasivoResult.fallos.map((f, i) => (
                      <li key={`${f.tipo}-${f.numero}-${i}`}>
                        {f.tipo} #{f.numero}: {f.detalle}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
            {reprocesoMasivoResult && (
              <div
                className={`mx-5 md:mx-8 mt-4 mb-2 rounded-xl border px-4 py-3 text-xs md:text-sm font-semibold ${reprocesoMasivoResult.ok
                  ? "border-emerald-200 bg-emerald-50 text-emerald-900"
                  : "border-rose-200 bg-rose-50 text-rose-900"
                  }`}
              >
                <p className="font-bold text-[10px] uppercase tracking-wide text-zinc-500">Reproceso masivo (Dynamics)</p>
                <p className="mt-1">{reprocesoMasivoResult.text}</p>
                {reprocesoMasivoResult.fallos && reprocesoMasivoResult.fallos.length > 0 && (
                  <ul className="mt-2 max-h-32 overflow-y-auto space-y-1 font-mono text-[10px] md:text-xs font-normal list-disc pl-4">
                    {reprocesoMasivoResult.fallos.map((f, i) => (
                      <li key={`repro-${f.tipo}-${f.numero}-${i}`}>
                        {f.tipo} #{f.numero}: {f.detalle}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {/* Mobile View: Cards */}
            <div className="block lg:hidden divide-y divide-zinc-100">
              {listaVisible.length === 0 ? (
                <div className="px-8 py-20 text-center flex flex-col items-center gap-4 text-zinc-300">
                  <Search className="w-10 h-10 opacity-20" />
                  <p className="text-xs font-bold opacity-50">No hay documentos para esta vista.</p>
                </div>
              ) : (
                listaVisible.map((d, i) => {
                  const siiStatus = d.estadoSII === 2;
                  const dynStatus = d.estadoEnvio === 3;
                  const dynWarn = d.estadoEnvio === 1 || d.estadoEnvio === 2;
                  const lineasState = getLineasSyncState(d);

                  return (
                    <motion.div
                      key={d.idDocumento ?? `${d.tipo}-${d.numero}`}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.01 }}
                      className="p-5 space-y-4 active:bg-zinc-50 transition-colors"
                      onClick={() => onVerDetalle(d.numero)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="px-2 py-0.5 rounded-md bg-zinc-900 text-white text-[9px] font-black tracking-tight">
                            {d.tipo}
                          </span>
                          <span className="text-sm font-black text-zinc-900 tabular-nums">#{d.numero}</span>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-zinc-300" />
                      </div>

                      <div className="flex items-center justify-between gap-4">
                        <div className="flex flex-col gap-1">
                          <span className="text-[9px] text-zinc-400 font-bold uppercase tracking-wider">SII</span>
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-tight border ${siiStatus ? "bg-emerald-50 text-emerald-700 border-emerald-100/50" : "bg-rose-50 text-rose-700 border-rose-100/50"
                            }`}>
                            {getSiiLabel(d.estadoSII)}
                          </span>
                        </div>
                        <div className="flex flex-col gap-1 items-end">
                          <span className="text-[9px] text-zinc-400 font-bold uppercase tracking-wider">Dynamics</span>
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-tight border ${dynStatus
                            ? "bg-emerald-50 text-emerald-700 border-emerald-100/50"
                            : dynWarn
                              ? "bg-amber-50 text-amber-700 border-amber-100/50"
                              : "bg-zinc-50 text-zinc-600 border-zinc-100"
                            }`}>
                            {getDynLabel(d.estadoEnvio)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-1 text-zinc-400">
                          <Clock className="w-3 h-3 opacity-50" />
                          <span className="text-[10px] font-semibold">{d.fechaEmision.slice(11, 16)}</span>
                        </div>
                        <div className={`text-[10px] font-bold ${!lineasState.hasLineas ? "text-zinc-600" : lineasState.complete ? "text-emerald-700" : "text-amber-700"}`}>
                          {lineasState.total}/{lineasState.synced} <span className="opacity-60">LÍNEAS</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>

            {/* Desktop View: Main Table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full text-sm border-separate border-spacing-0">
                <thead>
                  <tr className="text-left bg-zinc-50/30">
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">
                      <div className="flex items-center gap-2">
                        TIPO
                        <select
                          value={filtroColTipo}
                          onChange={e => setFiltroColTipo(e.target.value)}
                          className="bg-transparent border-none text-[10px] p-0 font-black text-indigo-500 focus:ring-0 appearance-none cursor-pointer"
                        >
                          <option value="">(TODOS)</option>
                          <option value="BLE">BLE</option>
                          <option value="FCV">FCV</option>
                          <option value="NCV">NCV</option>
                        </select>
                      </div>
                    </th>
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">DOCUMENTO</th>
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 hidden lg:table-cell">EMISIÓN</th>
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">
                      <div className="flex items-center gap-2">
                        SII
                        <select
                          value={filtroColSII}
                          onChange={e => setFiltroColSII(e.target.value)}
                          className="bg-transparent border-none text-[10px] p-0 font-black text-indigo-500 focus:ring-0 appearance-none cursor-pointer"
                        >
                          <option value="">(TODOS)</option>
                          <option value="2">Timbrado</option>
                          <option value="1">Sin timbrar</option>
                        </select>
                      </div>
                    </th>
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">
                      <div className="flex items-center gap-2">
                        DYNAMICS
                        <select
                          value={filtroColDynamics}
                          onChange={e => setFiltroColDynamics(e.target.value)}
                          className="bg-transparent border-none text-[10px] p-0 font-black text-indigo-500 focus:ring-0 appearance-none cursor-pointer"
                        >
                          <option value="">(TODOS)</option>
                          <option value="0">Sin enviar</option>
                          <option value="1">Enviada</option>
                          <option value="2">Loc. OK</option>
                          <option value="3">Registrado</option>
                          <option value="4">Medio de pago listo</option>
                        </select>
                      </div>
                    </th>
                    <th className="px-8 py-4 text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 text-right">LÍNEAS T/S</th>
                    <th className="px-8 py-4 border-b border-zinc-100" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-50">
                  {listaVisible.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-8 py-32 text-center">
                        <div className="flex flex-col items-center gap-4 text-zinc-300">
                          <Search className="w-12 h-12 opacity-20" />
                          <p className="text-sm font-bold opacity-50">No hay documentos para esta vista.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    listaVisible.map((d, i) => {
                      const siiStatus = d.estadoSII === 2;
                      const dynStatus = d.estadoEnvio === 3;
                      const dynWarn = d.estadoEnvio === 1 || d.estadoEnvio === 2;
                      const lineasState = getLineasSyncState(d);

                      return (
                        <motion.tr
                          key={d.idDocumento ?? `${d.tipo}-${d.numero}`}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.01 }}
                          className="hover:bg-zinc-50/80 transition-all duration-300 group"
                        >
                          <td className="px-8 py-4">
                            <span className="inline-flex px-2 py-1 rounded-md bg-zinc-900 text-white text-[10px] font-black tracking-tight group-hover:scale-105 transition-transform">
                              {d.tipo}
                            </span>
                          </td>
                          <td className="px-8 py-4">
                            <div className="flex flex-col">
                              <span className="text-sm font-black text-zinc-900 tabular-nums">#{d.numero}</span>
                              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{d.idDocumento.substring(0, 8)}...</span>
                            </div>
                          </td>
                          <td className="px-8 py-4 hidden lg:table-cell">
                            <div className="flex items-center gap-2 text-zinc-500">
                              <Clock className="w-3.5 h-3.5 opacity-50" />
                              <span className="text-xs font-semibold">{d.fechaEmision.slice(0, 16)}</span>
                            </div>
                          </td>
                          <td className="px-8 py-4">
                            <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-tight border ${siiStatus ? "bg-emerald-50 text-emerald-700 border-emerald-100/50" : "bg-rose-50 text-rose-700 border-rose-100/50"
                              }`}>
                              <div className={`w-1.5 h-1.5 rounded-full ${siiStatus ? "bg-emerald-500" : "bg-rose-500"}`} />
                              {getSiiLabel(d.estadoSII)}
                            </span>
                          </td>
                          <td className="px-8 py-4">
                            <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-tight border ${dynStatus
                              ? "bg-emerald-50 text-emerald-700 border-emerald-100/50"
                              : dynWarn
                                ? "bg-amber-50 text-amber-700 border-amber-100/50"
                                : "bg-zinc-50 text-zinc-600 border-zinc-100"
                              }`}>
                              <div className={`w-1.5 h-1.5 rounded-full ${dynStatus ? "bg-emerald-500" : dynWarn ? "bg-amber-500" : "bg-zinc-400"}`} />
                              {getDynLabel(d.estadoEnvio)}
                            </span>
                          </td>
                          <td className="px-8 py-4 text-right">
                            <span className={`text-sm font-black ${!lineasState.hasLineas ? "text-zinc-700" : lineasState.complete ? "text-emerald-700" : "text-amber-700"}`}>
                              {lineasState.total}/{lineasState.synced}
                            </span>
                          </td>
                          <td className="px-8 py-4 text-right">
                            <button
                              onClick={() => onVerDetalle(d.numero)}
                              className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-white rounded-lg transition-all active:scale-90 border border-transparent hover:border-zinc-200 hover:shadow-sm"
                            >
                              <ArrowUpRight className="w-5 h-5" />
                            </button>
                          </td>
                        </motion.tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination / Footer */}
            <div className="px-5 py-5 md:px-8 md:py-5 bg-zinc-900 border-t border-zinc-800 flex flex-col sm:flex-row flex-wrap items-center justify-between gap-4 md:gap-6">
              <div className="flex items-center gap-4 md:gap-6 self-start sm:self-center">
                <div className="flex items-center gap-2 text-[9px] md:text-[10px] font-black text-zinc-500 uppercase tracking-widest">
                  <Info className="w-3 h-3 md:w-3.5 md:h-3.5" />
                  <span className="hidden xs:inline">Mostrando</span> {desde}-{hasta} de {total}
                </div>

                <div className="h-4 w-px bg-zinc-800 hidden xs:block" />

                <div className="flex items-center gap-2 md:gap-3">
                  <span className="text-[9px] md:text-[10px] font-bold text-zinc-600 uppercase">Filas</span>
                  <select
                    value={pageSize}
                    onChange={e => loadDocumentos(1, Number(e.target.value))}
                    className="bg-zinc-800 border-zinc-700 rounded-lg text-[9px] md:text-[10px] font-black text-white px-2 py-1 outline-none focus:ring-2 focus:ring-indigo-500 transition-all appearance-none cursor-pointer pr-5 md:pr-6 relative"
                    style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'white\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 4px center', backgroundSize: '10px md:12px' }}
                  >
                    {PAGE_SIZES.map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
              </div>

              {totalPaginas > 1 && (
                <div className="flex items-center gap-2 md:gap-4 w-full sm:w-auto justify-center">
                  <button
                    onClick={() => handlePageChange(page - 1)}
                    disabled={page <= 1 || loading}
                    className="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-zinc-800 text-white flex items-center justify-center hover:bg-zinc-700 transition-all border border-zinc-700 disabled:opacity-20 disabled:pointer-events-none active:scale-95 shadow-lg"
                  >
                    <ChevronLeft className="w-4 h-4 md:w-5 md:h-5" />
                  </button>

                  <div className="px-3 md:px-4 h-8 md:h-10 bg-zinc-800 rounded-xl border border-zinc-700 flex items-center gap-1.5 md:gap-2">
                    <span className="text-[10px] md:text-[11px] font-black text-white tabular-nums">{page}</span>
                    <span className="text-[9px] md:text-[10px] font-bold text-zinc-600 uppercase italic">de</span>
                    <span className="text-[10px] md:text-[11px] font-black text-zinc-500 tabular-nums">{totalPaginas}</span>
                  </div>

                  <button
                    onClick={() => handlePageChange(page + 1)}
                    disabled={page >= totalPaginas || loading}
                    className="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-zinc-800 text-white flex items-center justify-center hover:bg-zinc-700 transition-all border border-zinc-700 disabled:opacity-20 disabled:pointer-events-none active:scale-95 shadow-lg"
                  >
                    <ChevronRight className="w-4 h-4 md:w-5 md:h-5" />
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}
